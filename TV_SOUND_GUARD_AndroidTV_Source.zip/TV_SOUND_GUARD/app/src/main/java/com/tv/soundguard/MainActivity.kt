package com.tv.soundguard

import android.app.Activity
import android.media.audiofx.AudioEffect
import android.media.audiofx.Equalizer
import android.media.audiofx.BassBoost
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private lateinit var status: TextView
    private lateinit var eqContainer: LinearLayout
    private lateinit var bassLabel: TextView
    private lateinit var bassSeek: SeekBar
    private var effectAvailable = false
    private val prefs by lazy { getSharedPreferences("sound_guard", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(Color.rgb(13, 19, 32))
        buildScreen()
        openAudioEffects()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(22), dp(28), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "TV SOUND GUARD"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(8))
        })
        root.addView(TextView(this).apply {
            text = "Audio controls for Xiaomi / Mi TV"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(18))
        })

        status = TextView(this).apply {
            text = "Checking TV audio support…"
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(35, 48, 69))
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(status, matchWidth())

        val note = TextView(this).apply {
            text = "Important: Android TV may block global audio effects. If blocked, these controls cannot change sound from YouTube, HDMI or other apps. This app does not yet perform true automatic noise cancellation or dynamic volume compression."
            textSize = 13f
            setTextColor(Color.rgb(255, 211, 130))
            setPadding(0, dp(14), 0, dp(18))
        }
        root.addView(note)

        root.addView(section("SOUND PROFILES"))
        val profiles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Normal", "Speech", "Movie", "Night").forEach { name ->
            val b = Button(this).apply {
                text = name
                isAllCaps = false
                textSize = 12f
                setOnClickListener { applyProfile(name) }
            }
            profiles.addView(b, LinearLayout.LayoutParams(0, dp(54), 1f).apply {
                marginEnd = dp(5)
            })
        }
        root.addView(profiles)

        root.addView(section("EQUALIZER"))
        eqContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(eqContainer)

        root.addView(section("BASS"))
        bassLabel = TextView(this).apply {
            text = "Bass boost: unavailable until audio effects connect"
            textSize = 14f
            setTextColor(Color.WHITE)
        }
        root.addView(bassLabel)
        bassSeek = SeekBar(this).apply {
            max = 100
            progress = 0
            isEnabled = false
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, value: Int, user: Boolean) {
                    bassLabel.text = "Bass boost: $value%"
                    try { bassBoost?.setStrength((value * 10).toShort()) } catch (_: Exception) {}
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(bassSeek)

        val refresh = Button(this).apply {
            text = "RETRY AUDIO CONNECTION"
            isAllCaps = false
            setOnClickListener {
                releaseEffects()
                openAudioEffects()
            }
        }
        root.addView(refresh, matchWidth())
        root.addView(TextView(this).apply {
            text = "TV SOUND GUARD  •  Version 1.0"
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, 0)
        })
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun section(title: String) = TextView(this).apply {
        text = title
        textSize = 17f
        setTextColor(Color.rgb(105, 190, 255))
        setPadding(0, dp(22), 0, dp(8))
    }

    private fun openAudioEffects() {
        try {
            // Audio session 0 requests the device's global output mix.
            // Many retail Android TVs do not allow third-party apps to control it.
            equalizer = Equalizer(0, 0).also { it.enabled = true }
            try {
                bassBoost = BassBoost(0, 0).also { it.enabled = true }
                bassSeek.isEnabled = true
                bassSeek.progress = 0
                bassLabel.text = "Bass boost: 0%"
            } catch (_: Exception) {
                bassBoost = null
                bassLabel.text = "Bass boost is not supported by this TV"
                bassSeek.isEnabled = false
            }
            effectAvailable = true
            status.text = "Audio effects connected. Global control may still depend on Xiaomi TV firmware."
            status.setTextColor(Color.rgb(140, 255, 170))
            buildEqualizerSliders()
        } catch (e: Exception) {
            effectAvailable = false
            status.text = "Global audio control is blocked or unsupported by this TV. Try the TV's built-in Sound settings."
            status.setTextColor(Color.rgb(255, 170, 150))
            eqContainer.removeAllViews()
            eqContainer.addView(TextView(this).apply {
                text = "No global equalizer access. The app cannot alter audio from other apps on this TV."
                setTextColor(Color.LTGRAY)
                textSize = 14f
            })
        }
    }

    private fun buildEqualizerSliders() {
        eqContainer.removeAllViews()
        val eq = equalizer ?: return
        try {
            val range = eq.bandLevelRange
            val min = range[0].toInt()
            val max = range[1].toInt()
            val bands = eq.numberOfBands.toInt()
            for (i in 0 until bands) {
                val band = i.toShort()
                val hz = eq.getCenterFreq(band) / 1000
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(0, dp(5), 0, dp(5))
                }
                val label = TextView(this).apply {
                    text = if (hz >= 1000) "${hz / 1000f} kHz" else "$hz Hz"
                    setTextColor(Color.WHITE)
                    textSize = 14f
                }
                val seek = SeekBar(this).apply {
                    max = max - min
                    progress = (eq.getBandLevel(band).toInt() - min).coerceIn(0, max - min)
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                            if (user) {
                                try { eq.setBandLevel(band, (p + min).toShort()) } catch (_: Exception) {}
                            }
                        }
                        override fun onStartTrackingTouch(s: SeekBar?) {}
                        override fun onStopTrackingTouch(s: SeekBar?) {}
                    })
                }
                row.addView(label)
                row.addView(seek)
                eqContainer.addView(row)
            }
        } catch (_: Exception) {
            eqContainer.addView(TextView(this).apply {
                text = "The TV did not expose equalizer bands."
                setTextColor(Color.LTGRAY)
            })
        }
    }

    private fun applyProfile(profile: String) {
        val eq = equalizer
        if (eq == null) {
            Toast.makeText(this, "No global audio effect connection", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val bands = eq.numberOfBands.toInt()
            val range = eq.bandLevelRange
            val min = range[0].toInt()
            val max = range[1].toInt()
            val values = when (profile) {
                "Speech" -> listOf(-2, 3, 5, 4, 1)
                "Movie" -> listOf(3, 1, -1, 2, 4)
                "Night" -> listOf(2, 2, 1, 0, -1)
                else -> listOf(0, 0, 0, 0, 0)
            }
            for (i in 0 until bands) {
                val normalized = values[(i * values.size / bands).coerceIn(0, values.lastIndex)]
                val levelMb = (normalized * 100).coerceIn(min, max)
                eq.setBandLevel(i.toShort(), levelMb.toShort())
            }
            if (profile == "Night") {
                try { bassBoost?.setStrength(0) } catch (_: Exception) {}
                bassSeek.progress = 0
            }
            Toast.makeText(this, "$profile profile applied where supported", Toast.LENGTH_SHORT).show()
            buildEqualizerSliders()
        } catch (e: Exception) {
            Toast.makeText(this, "TV rejected this audio setting", Toast.LENGTH_LONG).show()
        }
    }

    private fun releaseEffects() {
        try { equalizer?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        equalizer = null
        bassBoost = null
    }

    override fun onDestroy() {
        releaseEffects()
        super.onDestroy()
    }
}
